EDTASM6309 will work with Riger Taylor's DrivePak and can be installed on any drive #
in the DOS partition; 0-255. However, the program will only work correctly when that
drive is made "DRIVE0" with the command 		DRIVE0,#number

So if you copy the EDTASM6309 disk to drive #15, before using DOS.BAS or RGBCNFIG.BAS
you must enter DRIVE0,#15. Then RUN"RGBCNFIG" and indicate that the installation
drive is 0 regardless of which #number was used. For any subsequent use of the
program, you must first enter ex. DRIVE0,#15 before RUN"DOS".

To print from the editor or zbug, you will need Drivewire4 running on a PC and a serial
cable connecting your Coco to the PC.